# Zorbix FPS Boost V2

Fabric client-side mod for Minecraft 1.20.1.

## Features
- F8 toggles the boost on/off.
- Automatically lowers render distance when FPS stays below the low-FPS threshold.
- Gradually restores render distance after FPS stabilizes.
- Saves the player's original render distance and restores it when the mod is disabled.
- Configurable through `config/fpsboost.json`.
- English and Russian localization.

## Build
Requirements:
- Java 17
- Gradle 8.x (or use the included wrapper if you add one)

Run:
`./gradlew build`

The compiled JAR will be in `build/libs/`.

## Configuration
The mod creates `config/fpsboost.json` on first launch.

Default:
- low FPS: 35
- recovery FPS: 55
- check interval: 20 ticks
- reduction step: 2 chunks
- minimum render distance: 4
- maximum render distance: 16

The config is intentionally conservative: the mod does not alter world data, entities, graphics files, or server-side behavior.

## GitHub Actions

После загрузки проекта на GitHub сборка запускается автоматически при push/PR или вручную через **Actions → Build Zorbix FPS Boost V2 → Run workflow**.

Готовый `.jar` находится в результате workflow в разделе **Artifacts**.
