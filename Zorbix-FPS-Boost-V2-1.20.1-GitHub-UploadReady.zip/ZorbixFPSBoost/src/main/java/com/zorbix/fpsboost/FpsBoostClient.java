package com.zorbix.fpsboost;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.CloudRenderMode;
import net.minecraft.client.option.GraphicsMode;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.option.ParticlesMode;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDateTime;

public class FpsBoostClient implements ClientModInitializer {
    private int tickCounter = 0;
    private int lowFpsCounter = 0;
    private int highFpsCounter = 0;
    private int originalRenderDistance = -1;
    private int originalSimulationDistance = -1;
    private ParticlesMode originalParticles;
    private CloudRenderMode originalClouds;
    private GraphicsMode originalGraphics;
    private boolean originalAo;
    private boolean originalEntityShadows;
    private boolean enabled = true;
    private int mode = 0; // 0 SMART, 1 TURBO, 2 EXTREME
    private KeyBinding toggleKey;
    private KeyBinding modeKey;

    @Override
    public void onInitializeClient() {
        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.zorbix.toggle", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_F8, "category.zorbix"));
        modeKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.zorbix.mode", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_F7, "category.zorbix"));

        ClientTickEvents.END_CLIENT_TICK.register(this::onTick);
        HudRenderCallback.EVENT.register((drawContext, tickDelta) -> renderHud(drawContext));
    }

    private void onTick(MinecraftClient client) {
        while (toggleKey.wasPressed()) {
            enabled = !enabled;
            if (!enabled) restoreSettings(client);
        }
        while (modeKey.wasPressed()) mode = (mode + 1) % 3;

        if (!enabled || client.options == null || client.world == null) return;
        tickCounter++;
        if (tickCounter % 20 != 0) return;

        saveOriginalSettings(client);
        int fps = client.getCurrentFps();
        applyBaseOptimization(client);

        if (mode == 0) smartMode(client, fps);
        else if (mode == 1) turboMode(client, fps);
        else extremeMode(client, fps);

        if (tickCounter % 100 == 0) logFps(fps);
    }

    private void saveOriginalSettings(MinecraftClient client) {
        if (originalRenderDistance != -1) return;
        originalRenderDistance = client.options.getViewDistance().getValue();
        originalSimulationDistance = client.options.getSimulationDistance().getValue();
        originalParticles = client.options.getParticles().getValue();
        originalClouds = client.options.getCloudRenderMode().getValue();
        originalGraphics = client.options.getGraphicsMode().getValue();
        originalAo = client.options.getAo().getValue();
        originalEntityShadows = client.options.getEntityShadows().getValue();
    }

    private void applyBaseOptimization(MinecraftClient client) {
        client.options.getParticles().setValue(ParticlesMode.MINIMAL);
        client.options.getCloudRenderMode().setValue(CloudRenderMode.OFF);
        client.options.getGraphicsMode().setValue(GraphicsMode.FAST);
        client.options.getAo().setValue(false);
        client.options.getEntityShadows().setValue(false);
    }

    private void smartMode(MinecraftClient client, int fps) {
        if (fps < 20) {
            lowFpsCounter++; highFpsCounter = 0;
            if (lowFpsCounter >= 2) setDistance(client, 2, 2);
        } else if (fps < 30) {
            lowFpsCounter++; highFpsCounter = 0;
            if (lowFpsCounter >= 2) setDistance(client, 3, 3);
        } else if (fps < 40) {
            lowFpsCounter++; highFpsCounter = 0;
            if (lowFpsCounter >= 2) client.options.getViewDistance().setValue(4);
        } else {
            lowFpsCounter = 0; highFpsCounter++;
            if (fps > 80 && highFpsCounter >= 5) { increaseRenderDistance(client); highFpsCounter = 0; }
        }
    }

    private void turboMode(MinecraftClient client, int fps) {
        if (fps < 25) setDistance(client, 2, 2);
        else if (fps < 40) setDistance(client, 3, 3);
        else if (fps < 60) client.options.getViewDistance().setValue(5);
        else if (fps > 100) increaseRenderDistance(client);
    }

    private void extremeMode(MinecraftClient client, int fps) {
        if (fps < 30) setDistance(client, 2, 2);
        else if (fps < 50) setDistance(client, 3, 3);
        else if (fps < 70) client.options.getViewDistance().setValue(4);
        else if (fps > 120) increaseRenderDistance(client);
    }

    private void setDistance(MinecraftClient client, int render, int simulation) {
        client.options.getViewDistance().setValue(Math.max(2, render));
        client.options.getSimulationDistance().setValue(Math.max(2, simulation));
    }

    private void increaseRenderDistance(MinecraftClient client) {
        int current = client.options.getViewDistance().getValue();
        if (current < originalRenderDistance) client.options.getViewDistance().setValue(current + 1);
    }

    private void restoreSettings(MinecraftClient client) {
        if (originalRenderDistance == -1 || client.options == null) return;
        client.options.getViewDistance().setValue(originalRenderDistance);
        client.options.getSimulationDistance().setValue(originalSimulationDistance);
        client.options.getParticles().setValue(originalParticles);
        client.options.getCloudRenderMode().setValue(originalClouds);
        client.options.getGraphicsMode().setValue(originalGraphics);
        client.options.getAo().setValue(originalAo);
        client.options.getEntityShadows().setValue(originalEntityShadows);
    }

    private void renderHud(net.minecraft.client.gui.DrawContext drawContext) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (!enabled || client.player == null) return;
        String modeName = mode == 0 ? "SMART" : mode == 1 ? "TURBO" : "EXTREME";
        String text = "Zorbix V2 | " + modeName + " | FPS: " + client.getCurrentFps();
        drawContext.drawText(client.textRenderer, text, 5, 5, 0xFFFFFF, true);
    }

    private void logFps(int fps) {
        try (PrintWriter writer = new PrintWriter(new FileWriter(
                MinecraftClient.getInstance().runDirectory + "/fps_log.txt", true))) {
            writer.println(LocalDateTime.now() + " | Zorbix V2 | Mode: " + mode + " | FPS: " + fps);
        } catch (IOException ignored) { }
    }
}
